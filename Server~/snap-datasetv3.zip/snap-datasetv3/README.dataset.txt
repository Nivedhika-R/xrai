# snap-circuits > dataset v3
https://universe.roboflow.com/cogassist/snap-circuits

Provided by a Roboflow user
License: CC BY 4.0

